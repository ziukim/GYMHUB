package com.kh.gymhub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymhubApplicationTests {

	@Test
	void contextLoads() {
	}

}
